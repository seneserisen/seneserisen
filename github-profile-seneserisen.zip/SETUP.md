# GitHub Profile Setup — seneserisen

This package is designed for the public profile repository:

`seneserisen/seneserisen`

## Files

- `README.md` — English-first professional engineering profile with a collapsible Turkish summary.
- `.github/workflows/profile-visuals.yml` — weekly generation of the 3D contribution calendar and contribution snake.

## Publish through the GitHub website

1. Open `https://github.com/seneserisen/seneserisen`.
2. Open `README.md`, click the pencil icon, replace the complete file with the supplied `README.md`, and commit:
   - Commit message: `docs: redesign engineering profile`
3. Create `.github/workflows/profile-visuals.yml` and paste the supplied workflow.
   - Commit message: `ci: add profile visual generation`
4. Open **Settings → Actions → General → Workflow permissions**.
5. Select **Read and write permissions**, then save.
6. Open **Actions → Generate Profile Visuals → Run workflow**.
7. Wait for the workflow to complete, then refresh the profile. The 3D graph and snake will appear after the first successful run.

## GitHub profile fields to update manually

Use the following concise profile metadata:

- **Name:** Sadik Enes Erisen
- **Bio:** `M.Sc. Autonomy Technologies @ FAU | Electrical & Electronics Engineer | Robotics, Embedded Systems, Control & Industrial AI`
- **Company/education:** `Friedrich-Alexander-Universität Erlangen-Nürnberg (FAU)`
- **Location:** `Bavaria, Germany`
- **Website:** Use LinkedIn or a portfolio only when the page is complete and current.

Remove outdated profile metadata such as an old university-only affiliation or an old location.

## Repositories to pin first

Pin completed, evidence-based work before planned or reference repositories:

1. `automatic-control-lab-projects`
2. `industrial-quality-anomaly-monitor`

Add other repositories only after they contain:

- a complete README;
- reproducible setup instructions;
- architecture or design documentation;
- automated tests;
- screenshots, plots, or measured results;
- explicit limitations and attribution.

Do not pin empty roadmap repositories or unchanged forks.

## Repository cleanup rule

Do not delete useful references immediately. For repositories that are only forks, tutorials, or saved resources:

- unpin them;
- archive them if you no longer develop them;
- keep only repositories that support your target identity: robotics, embedded systems, control, autonomous systems, and industrial engineering software.

## Language strategy

- Keep roughly 85–90% of the profile in English for German and international recruiters.
- Keep Turkish as a secondary collapsible summary.
- Do not duplicate the entire README in Turkish; it makes the profile too long and weakens recruiter scanning.

## Security note

The visual workflow uses third-party GitHub Actions with `contents: write` permission in the profile repository. This is common for generated profile graphics, but it is still a supply-chain risk. Keep the workflow limited to this profile repository and consider replacing version tags with audited commit SHAs later.
